<template>
  <h1>  Function page</h1>
</template>