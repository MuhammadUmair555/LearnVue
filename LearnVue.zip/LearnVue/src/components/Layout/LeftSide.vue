<template>
   <div class="leftSide">
    <h1>Leftside</h1>
    <div class="leftTabs">
        <ul>
            <li>Add textarea</li>
            <li>Add card</li>
            <li>Add inputs</li>
            <li>Add buttons</li>
            <li>Add images</li>
            
        </ul>

       
    </div>
   </div>
</template>