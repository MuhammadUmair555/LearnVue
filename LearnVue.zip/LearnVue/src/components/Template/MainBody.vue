<template>
  <div class="mainBody">
   <div class="content">
      <h1>Heading</h1>
      <p>
         The above code has made the text and image centered vertically. To take care of both vertical and horizontal centering, we need to make a little tweak in the CSS. We'll set the top property to 50%, and we'll add a transform on both the X and Y axes.
      </p>
   </div>
  </div>
</template>