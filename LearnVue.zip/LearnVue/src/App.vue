<script setup>

import MainWrapper from "./components/MainWrapper.vue";
import Function from "./views/Function.vue";
import Explore from "./views/Explore.vue";
</script>

<template>
  <MainWrapper />
  <Function />
  <Explore />

</template>

<style scoped>
</style>
